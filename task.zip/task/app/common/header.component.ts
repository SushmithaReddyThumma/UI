import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-header',
  templateUrl: './header.component.html',
  styleUrls: ['./home.component.css']
})
export class HeaderComponent {
  constructor() {}
}
