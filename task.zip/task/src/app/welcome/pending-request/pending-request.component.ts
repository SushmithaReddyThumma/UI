import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-request',
  templateUrl: './pending-request.component.html',
  styleUrls: ['./pending-request.component.css']
})
export class PendingRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
