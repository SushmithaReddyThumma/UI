import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestus',
  templateUrl: './requestus.component.html',
  styleUrls: ['./requestus.component.css']
})
export class RequestusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
